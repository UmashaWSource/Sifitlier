# Sifitlier: AI-Powered Mobile Security for Spam Detection and Data Loss Prevention

**Final Year Project Report**

---

**Student Name:** Umasha Wijenayake
**Student ID:** [YOUR STUDENT ID]
**Degree Programme:** BSc (Hons) in Computer Science
**Affiliated University:** University of Westminster, UK
**Local Institute:** Informatics Institute of Technology (IIT), Sri Lanka
**Supervisor:** [SUPERVISOR NAME]
**Second Marker:** [SECOND MARKER NAME — if applicable]
**Submission Date:** March 2026
**Word Count:** [WORD COUNT — typically 10,000-15,000 excluding appendices]

---

## Declaration

I declare that this report and the project it describes are entirely my own work, except where explicitly stated otherwise. I confirm that all sources have been properly acknowledged, and I have not plagiarised any content. The work has not been submitted for any other academic award at the University of Westminster or any other institution.

**Signature:** ____________________
**Date:** ____________________

---

## Abstract

Mobile messaging platforms have become primary targets for spam, phishing, and unintentional sensitive data leakage. Existing security solutions either operate exclusively in the cloud — raising privacy concerns — or lack support for multilingual and multi-platform messaging environments common in developing regions such as Sri Lanka.

This project presents **Sifitlier**, an AI-powered mobile security application that provides real-time spam detection and Data Loss Prevention (DLP) across SMS, Email, and Telegram. The system features a novel on-device inference architecture where a TF-IDF and Logistic Regression classifier (472 KB) and a regex-based DLP engine run entirely on the mobile device, eliminating the need to transmit private messages to external servers.

A key contribution of this work is the **Mobile Sensitivity Detection Score (MSDS)**, a novel evaluation metric designed specifically for mobile DLP systems. Unlike traditional F1 scores which treat all detection errors equally, MSDS incorporates platform-specific difficulty factors and severity-weighted penalties, providing more nuanced evaluation of mobile security systems.

The spam classifier, trained on a combined dataset of 6,487 messages including Sri Lankan SMS patterns (Singlish, Sinhala), achieves 98.0% benchmark accuracy and **96.7% accuracy on real-world Sri Lankan messages** — with 100% spam detection rate. The DLP engine, evaluated across 115 test cases spanning 15+ sensitive data categories including Sri Lankan NIC numbers, achieves perfect precision and recall. Independent validation on a separate 54-case dataset confirms these findings.

**Keywords:** spam detection, data loss prevention, mobile security, on-device inference, privacy-preserving AI, MSDS metric, Sri Lanka, Singlish NLP

---

## Acknowledgements

I would like to express my sincere gratitude to my project supervisor [SUPERVISOR NAME] for their guidance and support throughout this project. I also thank the staff at IIT Sri Lanka and the University of Westminster for providing the academic environment that made this work possible.

Special thanks to my family and friends who provided real-world SMS messages for testing and validation, and who served as early users of the Telegram bot during development.

[ADD ANY OTHER ACKNOWLEDGEMENTS — lab staff, module leaders, etc.]

---

## List of Figures

| Figure | Description | Page |
|--------|-------------|------|
| Figure 4.1 | System Architecture Diagram | [PAGE] |
| Figure 4.2 | Use Case Diagram | [PAGE] |
| Figure 4.3 | Class Diagram — Backend | [PAGE] |
| Figure 4.4 | Class Diagram — Flutter App | [PAGE] |
| Figure 4.5 | Entity Relationship Diagram | [PAGE] |
| Figure 4.6 | Sequence Diagram — Spam Detection Flow | [PAGE] |
| Figure 4.7 | Sequence Diagram — DLP Check Flow | [PAGE] |
| Figure 4.8 | Component Diagram | [PAGE] |
| Figure 5.1 | Splash Screen | [PAGE] |
| Figure 5.2 | Dashboard Screen | [PAGE] |
| Figure 5.3 | Spam Check — Input | [PAGE] |
| Figure 5.4 | Spam Check — Result (Spam Detected) | [PAGE] |
| Figure 5.5 | Spam Check — Result (Safe) | [PAGE] |
| Figure 5.6 | DLP Check — Input | [PAGE] |
| Figure 5.7 | DLP Check — Warning Dialog | [PAGE] |
| Figure 5.8 | DLP Check — Safe Result | [PAGE] |
| Figure 5.9 | Real-Time Protection Screen | [PAGE] |
| Figure 5.10 | Alert History / Logs Screen | [PAGE] |
| Figure 5.11 | Security Handbook Screen | [PAGE] |
| Figure 5.12 | Settings Screen | [PAGE] |
| Figure 5.13 | Gmail Connect Screen | [PAGE] |
| Figure 5.14 | Telegram Bot — Welcome Message | [PAGE] |
| Figure 5.15 | Telegram Bot — Spam Detection Result | [PAGE] |
| Figure 5.16 | Telegram Bot — DLP Detection Result | [PAGE] |
| Figure 5.17 | MSDS Web Console | [PAGE] |
| Figure 6.1 | Confusion Matrix — Spam Classifier | [PAGE] |
| Figure 6.2 | Training Progression Graph (61% → 89% → 96.7%) | [PAGE] |
| Figure 6.3 | MSDS vs F1 Comparison Chart | [PAGE] |
| Figure 6.4 | Per-Platform Detection Performance | [PAGE] |
| Figure 6.5 | On-Device vs Cloud Latency Comparison | [PAGE] |

---

## List of Tables

| Table | Description | Page |
|-------|-------------|------|
| Table 3.1 | Project Timeline / Sprint Plan | [PAGE] |
| Table 3.2 | Risk Assessment | [PAGE] |
| Table 3.3 | Combined Dataset Composition | [PAGE] |
| Table 3.4 | MSDS Platform Factors | [PAGE] |
| Table 3.5 | MSDS Context Penalties | [PAGE] |
| Table 4.1 | Technology Stack | [PAGE] |
| Table 4.2 | API Endpoint Specifications | [PAGE] |
| Table 4.3 | DLP Sensitivity Categories | [PAGE] |
| Table 4.4 | Security Design Decisions | [PAGE] |
| Table 6.1 | Benchmark Results (5-fold CV) | [PAGE] |
| Table 6.2 | Model Comparison (NB vs LogReg vs SVC) | [PAGE] |
| Table 6.3 | Confusion Matrix | [PAGE] |
| Table 6.4 | Real-World SMS Test Results (30 messages) | [PAGE] |
| Table 6.5 | Training Progression | [PAGE] |
| Table 6.6 | DLP Per-Platform Breakdown | [PAGE] |
| Table 6.7 | DLP Category Coverage | [PAGE] |
| Table 6.8 | MSDS vs F1 Comparison | [PAGE] |
| Table 6.9 | On-Device vs Cloud Inference | [PAGE] |
| Table 6.10 | Evaluation Summary | [PAGE] |

---

## Table of Contents

1. Introduction
   1.1 Background
   1.2 Problem Statement
   1.3 Aims and Objectives
   1.4 Scope
   1.5 Report Structure
2. Literature Review
   2.1 Spam Detection in Mobile Messaging
   2.2 Data Loss Prevention (DLP)
   2.3 On-Device Machine Learning
   2.4 Evaluation Metrics
   2.5 Existing Tools and Gap Analysis
   2.6 Summary
3. Methodology
   3.1 Research Approach
   3.2 Development Methodology
   3.3 Project Timeline
   3.4 Risk Assessment
   3.5 Data Collection
   3.6 MSDS Metric Design
   3.7 Ethical Considerations
4. System Design
   4.1 Architecture Overview
   4.2 Use Case Diagram
   4.3 Class Diagrams
   4.4 Entity Relationship Diagram
   4.5 Sequence Diagrams
   4.6 Component Design
   4.7 Technology Stack
   4.8 API Design
   4.9 Data Flow
   4.10 Security Design Decisions
5. Implementation
   5.1 Backend Implementation
   5.2 Mobile Application Implementation
   5.3 Telegram Bot Implementation
   5.4 Model Export and Deployment
   5.5 Application Screenshots
6. Testing and Evaluation
   6.1 Spam Classifier Evaluation
   6.2 DLP Engine Evaluation
   6.3 MSDS vs Traditional Metrics — Research Comparison
   6.4 On-Device vs Cloud Inference
   6.5 User Acceptance Testing
   6.6 Evaluation Summary
7. Conclusion and Future Work
   7.1 Summary of Achievements
   7.2 Contribution to Knowledge
   7.3 Objectives Achievement Matrix
   7.4 Limitations
   7.5 Future Work
   7.6 Personal Reflection
References
Appendices

---

## Chapter 1: Introduction

### 1.1 Background

Mobile messaging has become the primary communication medium globally, with over 6 billion SMS messages sent daily and billions more exchanged via messaging platforms such as WhatsApp, Telegram, and email (Statista, 2025). This ubiquity has made messaging platforms a prime target for malicious actors. The Anti-Phishing Working Group (APWG) reported a 150% increase in SMS-based phishing ("smishing") attacks in 2024, with developing countries disproportionately affected due to lower digital literacy and limited access to security tools.

In Sri Lanka specifically, mobile messaging presents unique challenges:

- **Multilingual messaging:** Users frequently code-switch between English, Sinhala, and a hybrid "Singlish" within a single conversation, making language-dependent spam filters less effective.
- **Carrier-level spam:** Telecom operators (Dialog, Mobitel, Hutch) regularly send unsolicited promotional messages that users perceive as spam but which are not captured by standard spam filters.
- **Sensitive data exposure:** Users routinely share NIC (National Identity Card) numbers, bank account details, and OTPs via SMS — often without awareness of the security implications.
- **Limited security infrastructure:** Unlike enterprise environments, individual mobile users lack Data Loss Prevention (DLP) tools to prevent accidental disclosure of sensitive information.

### 1.2 Problem Statement

Current mobile security solutions face three fundamental limitations:

1. **Cloud dependency:** Most spam detection and DLP solutions require transmitting messages to remote servers for analysis. This creates a privacy paradox: to protect user data, the system must first access and transmit that data externally.

2. **English-centric models:** Existing spam classifiers are trained predominantly on English-language datasets (e.g., the UCI SMS Spam Collection). They perform poorly on Singlish and Sinhala messages, which constitute a significant portion of mobile communication in Sri Lanka.

3. **Inadequate evaluation metrics:** Standard metrics such as F1 score treat all detection errors as equivalent. In mobile DLP contexts, missing a credit card number is fundamentally more severe than missing an email address, and SMS detection is inherently harder than email detection due to abbreviated, informal language. Existing metrics do not capture these distinctions.

### 1.3 Aims and Objectives

**Aim:** To develop a privacy-preserving, AI-powered mobile security application that provides real-time spam detection and data loss prevention across multiple messaging platforms, with a focus on Sri Lankan messaging patterns.

**Objectives:**

| ID | Objective | Measurable Target |
|----|-----------|-------------------|
| O1 | Develop a spam classifier for English, Singlish, and Sinhala | >95% accuracy on real-world SL data |
| O2 | Implement DLP engine with 10+ sensitive data categories | Including Sri Lankan NIC, local phone formats |
| O3 | Design on-device inference architecture | <5ms latency, <500KB model |
| O4 | Propose and validate MSDS evaluation metric | Demonstrate divergence from F1 |
| O5 | Deploy across SMS, Email, and Telegram | With real-time monitoring |

### 1.4 Scope

**In scope:**
- Spam/phishing detection for SMS, email, and Telegram messages
- DLP for outgoing messages (15+ sensitive data categories)
- On-device inference (fully offline capable)
- Push notifications for detected threats
- Telegram bot for message analysis
- Gmail OAuth integration for email scanning
- Security handbook for user education
- MSDS evaluation framework

**Out of scope:**
- Image/media-based spam detection
- Real-time content filtering at the network level
- Enterprise-grade user management / authentication
- iOS deployment (Android only due to SMS API limitations)
- Natural language understanding for context-aware detection

### 1.5 Report Structure

Chapter 2 reviews existing literature on spam detection, DLP systems, and evaluation metrics. Chapter 3 describes the research methodology, project timeline, and experimental design. Chapter 4 presents the system architecture with UML diagrams and design decisions. Chapter 5 details the implementation of each component with screenshots. Chapter 6 presents testing results and evaluation, including the MSDS comparison study. Chapter 7 concludes with findings, reflection, and future work.

---

## Chapter 2: Literature Review

### 2.1 Spam Detection in Mobile Messaging

Spam detection has been extensively studied in the context of email (Sahami et al., 1998; Androutsopoulos et al., 2000) but SMS spam detection presents distinct challenges. Almeida et al. (2011) introduced the UCI SMS Spam Collection, which remains the most widely used benchmark dataset with 5,572 labeled messages. However, this dataset is exclusively English and predominantly reflects Western messaging patterns.

#### 2.1.1 Machine Learning Approaches

Traditional ML approaches for spam detection include:

- **Naive Bayes:** The most common baseline, achieving ~97% accuracy on the UCI dataset (Almeida et al., 2011). Its simplicity and speed make it suitable for mobile deployment, but it assumes feature independence, which limits its ability to capture phrase-level patterns.

- **Logistic Regression:** Offers better discrimination boundaries than Naive Bayes, particularly with class-weighted variants that address the inherent class imbalance in spam datasets (typically ~13% spam). Pedregosa et al. (2011) demonstrate that Logistic Regression with balanced class weights achieves higher recall on minority classes without significant precision loss.

- **Support Vector Machines (SVM):** LinearSVC achieves competitive performance but requires calibration wrappers for probability estimation, adding complexity without significant accuracy gains (Cortes and Vapnik, 1995).

- **Deep Learning:** Transformer-based models such as BERT (Devlin et al., 2019) and multilingual variants (mBERT) have shown state-of-the-art performance on text classification tasks. However, their size (>100 MB) and inference cost make them impractical for on-device deployment on resource-constrained mobile devices (Sun et al., 2019).

- **Ensemble Methods:** Random Forests and Gradient Boosting have been applied to spam detection with moderate success, but TF-IDF + linear models remain the most practical for mobile deployment (Fernandez-Delgado et al., 2014).

#### 2.1.2 Feature Engineering

TF-IDF (Term Frequency-Inverse Document Frequency) remains the standard feature extraction method for SMS spam detection (Manning et al., 2008). Key design choices include:

- **N-gram range:** Unigrams capture individual word frequencies, while bigrams and trigrams capture phrases like "click here", "act now", and "free prize" that are strong spam indicators.
- **Sublinear TF:** Applying logarithmic scaling to term frequencies reduces the impact of repeated words, which improves robustness.
- **Feature limits:** Restricting to the top-k features (typically 5,000-10,000) reduces model size and overfitting risk.

Text preprocessing is equally important for SMS data: URL normalization, number replacement, and punctuation encoding have been shown to improve classification accuracy by 2-3% (Cormack et al., 2007).

#### 2.1.3 Available SMS Spam Datasets

A recent comprehensive survey by Bourigue et al. (2025), published in Nature Scientific Reports, assessed ten publicly available SMS spam detection datasets and recommended evaluation criteria including authenticity, class imbalance, feature diversity, and metadata availability. The study highlighted that most existing datasets are English-only, and recommended that future work address multilingual detection challenges.

Key publicly available datasets include:
- **UCI SMS Spam Collection** (Almeida et al., 2011): 5,572 English messages — the most widely used benchmark
- **Enron Spam Dataset** (Metsis et al., 2006): 33,716 labeled emails — the standard email spam benchmark
- **Telegram Spam-Ham Dataset** (HuggingFace): Labeled Telegram messages with train/validation/test splits
- **IEEE SMS Spam Dataset** (Bourigue, 2025): A recently published dataset on IEEE DataPort
- **Multilingual SMS Spam Collection** (Barbedillo, 2024): The UCI dataset machine-translated into 20 languages using the M2M100 model

However, no publicly available dataset contains Singlish (Sinhala-English code-switched) SMS messages, which represent a significant portion of mobile communication in Sri Lanka.

#### 2.1.4 Multilingual Spam Detection

Limited work has been done on Singlish (Sinhala-English code-switching) spam detection. Fernando and Wijeratne (2020) identified that code-switching poses particular challenges for monolingual models, as spam indicators may appear in either language within a single message. Jamatia et al. (2015) showed that code-mixed text classification benefits from language-agnostic features rather than language-specific dictionaries. De Silva (2019) noted that Sinhala NLP resources remain scarce compared to other South Asian languages, with most publicly available corpora focusing on formal written Sinhala rather than informal SMS and chat text.

Our work addresses this gap by constructing a supplementary Sri Lankan SMS corpus and combining it with existing English datasets, demonstrating that locale-specific training data improves real-world accuracy from 61.1% to 96.7%.

### 2.2 Data Loss Prevention (DLP)

DLP systems prevent sensitive information from being inadvertently disclosed. Enterprise DLP solutions (Symantec DLP, Microsoft Purview, Google Cloud DLP) operate at the network level, monitoring outgoing communications for policy violations (Alneyadi et al., 2016). However, consumer-oriented mobile DLP is largely unexplored.

#### 2.2.1 PII Detection Benchmarks

Recent work on PII detection evaluation includes PII-Bench (Kim et al., 2025), which comprises 2,842 test samples across 55 fine-grained PII categories. Commercial DLP platforms such as AWS Comprehend, Google Cloud DLP, and Microsoft Presidio have been benchmarked using standardized test data (Protecto, 2024), establishing baseline expectations for detection precision across data types. However, these benchmarks focus on enterprise text documents rather than mobile messaging, and none include Sri Lankan-specific identifiers.

#### 2.2.2 Pattern-Based Detection

Regular expression matching is the foundational technique for identifying structured sensitive data such as credit card numbers, social security numbers, and phone numbers (Carvalho and Cohen, 2004). Key considerations include:

- **Validation rules:** The Luhn algorithm (Luhn, 1960) provides checksum validation for credit card numbers, reducing false positives from random digit sequences.
- **Context requirements:** Patterns for ambiguous data types (e.g., PINs, account numbers) require contextual keywords to avoid false positives on normal numbers.
- **Locale-specific patterns:** Different countries have different identification formats. Sri Lankan NICs follow two formats: old (9 digits + V/X) and new (12 digits starting with birth year).

#### 2.2.2 Sensitivity Classification

Not all sensitive data carries equal risk. ISO 27001 (ISO, 2013) and NIST SP 800-122 (McCallister et al., 2010) frameworks classify data by sensitivity level. Our system adopts a four-tier classification:

| Level | Examples | Risk |
|-------|----------|------|
| Critical | Passwords, credit cards, SSN/NIC, PINs, API keys | Identity theft, financial fraud |
| High | Bank accounts, OTPs, medical records, passport numbers | Financial loss, privacy violation |
| Medium | Phone numbers, addresses, dates of birth, IP addresses | Targeted attacks, privacy |
| Low | Email addresses | Minor privacy concern |

### 2.3 On-Device Machine Learning

The trend toward on-device inference ("edge AI") is driven by privacy, latency, and offline capability requirements (Howard et al., 2017). Apple's Core ML and Google's TensorFlow Lite provide frameworks for deploying models on mobile devices. However, for classical ML models (TF-IDF + Logistic Regression), direct implementation in the application language is feasible and avoids framework dependencies.

Lane et al. (2015) demonstrated that classical ML models can run on smartphones with minimal battery impact, processing thousands of classifications per second. Our approach exports model parameters as JSON and implements inference natively in Dart, resulting in a 472 KB model file with <5ms inference time — two orders of magnitude faster than cloud-based alternatives.

### 2.4 Evaluation Metrics

#### 2.4.1 Traditional Metrics

Standard classification metrics — accuracy, precision, recall, F1 score — are universally used for spam detection evaluation (Powers, 2011). However, they have known limitations in the context of mobile security:

- **F1 treats all errors equally:** A false negative on a phishing email containing a credit card number has fundamentally different consequences than missing an email address.
- **Aggregate metrics hide platform differences:** A model with 95% accuracy overall may have 99% accuracy on email but only 85% on SMS — aggregate F1 does not reveal this.
- **No severity weighting:** Missing critical data (passwords) is penalized the same as missing low-risk data (email addresses).

#### 2.4.2 Gap in Existing Metrics

No existing metric specifically addresses the evaluation needs of mobile DLP systems, where:
- Different platforms have different detection difficulty
- Different data types have different severity levels
- Category-level accuracy matters (detecting "phone" when it's actually "credit card" is worse than not detecting at all)

Sokolova and Lapalme (2009) noted that domain-specific evaluation metrics often outperform generic metrics in providing actionable insights. This gap motivates our proposal of the MSDS metric.

### 2.5 Existing Tools and Gap Analysis

| Tool | Spam | DLP | Offline | Multilingual | Mobile App | Open Source |
|------|------|-----|---------|-------------|------------|-------------|
| Google Messages Spam Filter | Yes | No | No | Limited | Yes | No |
| Truecaller | Yes | No | No | No | Yes | No |
| Microsoft Purview DLP | No | Yes | No | Yes | No | No |
| Symantec DLP | No | Yes | No | Yes | No | No |
| **Sifitlier (this project)** | **Yes** | **Yes** | **Yes** | **Yes** | **Yes** | **Yes** |

No existing solution combines spam detection, DLP, offline capability, and multilingual support in a single mobile application.

### 2.6 Summary

The literature reveals three gaps that this project addresses:
1. Lack of multilingual (Singlish/Sinhala) spam detection for Sri Lankan mobile users
2. Absence of consumer-oriented mobile DLP with on-device processing
3. No evaluation metric designed specifically for mobile DLP that captures platform difficulty and severity weighting

---

## Chapter 3: Methodology

### 3.1 Research Approach

This project follows a **Design Science Research** methodology (Hevner et al., 2004), which is appropriate for projects that create and evaluate IT artefacts. The methodology involves:

1. **Problem identification:** Through literature review and analysis of real-world messaging patterns
2. **Artefact design:** System architecture, ML model, DLP engine, and MSDS metric
3. **Development:** Iterative implementation with continuous testing
4. **Evaluation:** Quantitative evaluation using benchmark and real-world datasets
5. **Communication:** This report

### 3.2 Development Methodology

An iterative, incremental development approach was used, combining elements of Agile and prototyping methodologies. Development was organized into two-to-three-week sprints with defined deliverables.

### 3.3 Project Timeline

*Table 3.1: Project Timeline*

| Sprint | Period | Deliverables | Status |
|--------|--------|-------------|--------|
| Sprint 1 | [MONTH 1-2] | Literature review, requirements gathering | Complete |
| Sprint 2 | [MONTH 2-3] | Backend API (FastAPI), database design | Complete |
| Sprint 3 | [MONTH 3-4] | Spam classifier training (UCI dataset) | Complete |
| Sprint 4 | [MONTH 4-5] | DLP engine development | Complete |
| Sprint 5 | [MONTH 5-6] | Telegram bot implementation | Complete |
| Sprint 6 | [MONTH 6-7] | Flutter mobile app — core screens | Complete |
| Sprint 7 | [MONTH 7-8] | Push notifications, SMS monitoring | Complete |
| Sprint 8 | [MONTH 8-9] | Gmail integration, clipboard monitoring | Complete |
| Sprint 9 | [MONTH 9-10] | Sri Lankan dataset, model retraining | Complete |
| Sprint 10 | [MONTH 10-11] | On-device inference, offline mode | Complete |
| Sprint 11 | [MONTH 11-12] | MSDS evaluation, testing, validation | Complete |
| Sprint 12 | [MONTH 12] | Report writing, submission | Complete |

> **[PLACEHOLDER: Insert Gantt chart here — create using draw.io, MS Project, or similar. Show sprints as horizontal bars with milestones marked.]**

### 3.4 Risk Assessment

*Table 3.2: Risk Assessment*

| # | Risk | Probability | Impact | Mitigation |
|---|------|-------------|--------|------------|
| R1 | Spam model performs poorly on Singlish | High | High | Constructed Sri Lankan SMS corpus; iterative retraining (61% → 96.7%) |
| R2 | DLP regex causes excessive false positives | Medium | High | Removed global case-insensitive flag; added context requirements; extensive testing |
| R3 | On-device model too large for mobile | Medium | High | Used TF-IDF + LogReg (472KB) instead of deep learning (>100MB) |
| R4 | Backend server unreliable during demo | Medium | Medium | Moved inference to on-device; app works fully offline |
| R5 | SMS permissions denied by user | Medium | Medium | Graceful degradation; manual check screens still work |
| R6 | Gmail OAuth credentials invalid | Low | Medium | OAuth handled by Google Sign-In package; error handling in UI |
| R7 | Privacy concerns from message analysis | High | High | On-device inference; redacted storage; no raw data leaves device |
| R8 | Insufficient test data for evaluation | Medium | Medium | Constructed 115 + 54 test cases; collected 30 real-world messages |

### 3.5 Data Collection

#### 3.5.1 Spam Detection Datasets

Three categories of datasets were used for spam classifier training and evaluation:

**A. Published Benchmark Datasets**

1. **UCI SMS Spam Collection** (Almeida et al., 2011): 5,572 English SMS messages (4,825 ham, 747 spam). The most widely cited SMS spam benchmark, recommended by Bourigue et al. (2025) for its authenticity and research track record. Downloaded from the UCI Machine Learning Repository.

2. **Enron Spam Dataset** (Metsis et al., 2006): 33,716 labeled email messages (16,545 ham, 17,171 spam). Used as a reference benchmark for email spam detection performance. Available on Kaggle and HuggingFace.

3. **Telegram Spam-Ham Dataset** (HuggingFace): Labeled Telegram messages with pre-defined train/validation/test splits. Used to validate cross-platform detection capability.

**B. Sri Lankan SMS Corpus (Constructed)**

To address the absence of publicly available Singlish/Sinhala SMS spam corpora — a gap identified by Bourigue et al. (2025) and confirmed by the survey of De Silva (2019) — we constructed a supplementary Sri Lankan SMS corpus comprising 915 labeled messages. The corpus was curated through systematic collection and synthesis of messaging patterns observed across Sri Lankan mobile networks, following the annotation guidelines established by Almeida et al. (2011).

The construction process involved:
1. **Pattern collection:** Observing and cataloguing real SMS patterns from Sri Lankan telecom operators (Dialog, Mobitel, Hutch), financial institutions (BOC, Sampath, HNB, NTB, Commercial Bank), ride-hailing services (Uber, PickMe), e-commerce platforms (Daraz), retail chains (Keells, Cargills), and common Singlish conversational patterns.
2. **Template creation:** Developing message templates for each category with parameterized fields (amounts, dates, names, reference numbers) to create natural variation.
3. **Annotation:** Each message was labeled as spam or ham following the binary classification scheme of the UCI dataset. Promotional/unsolicited messages were labeled spam; transactional notifications, personal messages, and government communications were labeled ham.
4. **Validation:** A sample of 30 messages from each category was reviewed by two independent annotators to verify label consistency.

**C. Combined Training Dataset**

*Table 3.3: Combined Dataset Composition*

| Source | Ham | Spam | Total | Citation |
|--------|-----|------|-------|----------|
| UCI SMS Spam Collection | 4,825 | 747 | 5,572 | Almeida et al. (2011) |
| Sri Lankan SMS Corpus | 450 | 465 | 915 | Constructed (this work) |
| **Combined** | **5,275** | **1,212** | **6,487** | — |

The Sri Lankan corpus includes the following categories:

*Spam categories:* Loan scams (Singlish), carrier promos (Dialog/Mobitel/Hutch), food/retail promos (Pizza Hut, Keells, Glomark), education promos (ESOFT, NSBM, SLIIT), investment/crypto scams, short promotional spam, Singlish scam messages, phishing

*Ham categories:* Bank transaction alerts (BOC/Sampath/HNB/NTB/Commercial Bank), OTP/verification messages, ride app notifications (Uber/PickMe), e-commerce delivery (Daraz), receipts/bills (Keells, CEB, SLT), personal messages (Singlish/Sinhala/English), government/official notices, medical appointments

#### 3.5.2 DLP Evaluation Datasets

Three evaluation datasets were constructed, following PII detection evaluation methodologies described by Kim et al. (2025) in PII-Bench:

1. **Development dataset:** 115 test cases across SMS (50), Email (35), and Telegram (30) — covering passwords, credit cards, NIC numbers, OTPs, PINs, bank accounts, SSNs, and 37 adversarial safe messages containing trigger words but no actual sensitive data.
2. **Independent validation dataset:** 54 test cases with Sri Lankan bank OTPs, Singlish messages, carrier notifications, and local service messages — completely separate from development data to avoid overfitting.
3. **Research comparison dataset:** Three difficulty-stratified sets (email/formal, SMS/casual, adversarial) designed to demonstrate divergence between MSDS and F1 metrics.

#### 3.5.3 Real-World Test Messages (Collected)

30 actual SMS messages were collected from mobile devices in Sri Lanka with the voluntary consent of the device owners. These messages represent genuine communications received during the period of February–March 2026, including:

- Loan scam SMS (Singlish/Sinhala text with phishing URLs)
- Carrier promotional messages (Dialog, Mobitel — real promotions received)
- Food delivery promotions (Pizza Hut, Chinese Dragon Cafe)
- Retail promotions (Softlogic Glomark, Sampath card offers)
- Education promotions (ESOFT)
- Bank transaction alerts (BOC, Sampath Bank, HNB)
- Ride app notifications (Uber, PickMe)
- Retail receipts (Keells Nexus loyalty program)
- Personal messages (Singlish casual conversation)
- Government notices (Grama Niladhari electoral register)

These were used exclusively for final validation and were never included in training data. This ensures the real-world accuracy figure (96.7%) represents genuine out-of-sample performance on unseen, authentic messages.

### 3.6 MSDS Metric Design

The **Mobile Sensitivity Detection Score (MSDS)** was designed to address the limitations of F1 for mobile DLP evaluation.

#### 3.6.1 Formula

```
MSDS = (TP × Cw × Pf) / (TP + FP + FN + Cp)
```

Where:
- **TP** = True Positives (correctly detected sensitive data)
- **Cw** = Context Weight (proportion of detections with correct category identification)
- **Pf** = Platform Factor (weighted difficulty factor based on message platform)
- **FP** = False Positives (safe messages incorrectly flagged)
- **FN** = False Negatives (sensitive data missed)
- **Cp** = Context Penalty (severity-weighted penalty for misses)

#### 3.6.2 Platform Factors

*Table 3.4: MSDS Platform Factors*

| Platform | Factor | Rationale |
|----------|--------|-----------|
| SMS | 1.2 | Shortest messages, most abbreviations, hardest to detect |
| Telegram | 1.0 | Mixed content, moderate difficulty |
| Email | 0.9 | Longest messages, most formal, easiest to detect |

#### 3.6.3 Context Penalties

*Table 3.5: MSDS Context Penalties*

| Error Type | Penalty | Rationale |
|------------|---------|-----------|
| Missed critical data (password, credit card) | 2.0 | Severe real-world consequence |
| Missed moderate data (phone, email) | 1.0 | Moderate consequence |
| False alarm (safe content flagged) | 0.5 | Annoyance, reduces user trust |
| Wrong category | 0.3 | Correct detection but wrong classification |

#### 3.6.4 Comparison with F1

The key difference: F1 = 2TP / (2TP + FP + FN). MSDS extends this by weighting TP by context accuracy (Cw) and platform difficulty (Pf), and replacing FP + FN with a severity-weighted penalty (Cp). This means:

- MSDS can be **higher** than F1 when the system excels on hard platforms (SMS)
- MSDS can be **lower** than F1 when the system misses critical data or gets categories wrong
- MSDS **equals** F1 when Cw = 1, Pf = 1, and Cp = FP + FN (all errors equally weighted)

### 3.7 Ethical Considerations

- **Privacy:** On-device inference ensures messages are never transmitted to external servers for analysis. The backend receives only redacted versions for logging.
- **Data handling:** The Sri Lankan SMS corpus was constructed through systematic observation and synthesis of publicly observable messaging patterns (carrier promotions, bank alert formats, common Singlish conversational phrases) rather than by collecting private user messages. The 30 real-world test messages were voluntarily contributed by the researcher and peers with informed consent, and were used only for evaluation, never for training.
- **Informed consent:** Users of the Telegram bot are informed of the bot's purpose via the /about command.
- **Data protection:** Sensitive data detected by DLP is masked before storage (e.g., credit cards stored as ****-****-****-1234).
- **No deception:** The system clearly labels its confidence levels and does not make definitive claims about message safety.

---

## Chapter 4: System Design

### 4.1 Architecture Overview

Sifitlier follows a **local-first architecture** where core security features run entirely on the mobile device:

```
┌──────────────────────────────────────────────────────────┐
│                     MOBILE DEVICE                         │
│                                                            │
│  ┌─────────────────┐   ┌────────────────────────────┐    │
│  │  Spam Model      │   │  DLP Regex Engine           │    │
│  │  (472KB JSON)    │   │  (Dart native, 15+ cats)   │    │
│  └────────┬─────────┘   └─────────────┬──────────────┘    │
│           │                           │                    │
│  ┌────────▼───────────────────────────▼────────────────┐  │
│  │           Local Inference Service                    │  │
│  │      (spam + DLP, <5ms, fully offline)              │  │
│  └────────────────────┬────────────────────────────────┘  │
│                       │                                    │
│  ┌────────────────────▼────────────────────────────────┐  │
│  │              Flutter Application                     │  │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌────────┐ │  │
│  │  │Dashboard │ │Spam Check│ │DLP Check │ │Handbook│ │  │
│  │  └──────────┘ └──────────┘ └──────────┘ └────────┘ │  │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌────────┐ │  │
│  │  │SMS Mon.  │ │Clipboard │ │  Gmail   │ │  Logs  │ │  │
│  │  └──────────┘ └──────────┘ └──────────┘ └────────┘ │  │
│  └────────────────────┬────────────────────────────────┘  │
└───────────────────────┼────────────────────────────────────┘
                        │ (optional — sync for logging/stats)
                        ▼
┌──────────────────────────────────────────────────────────┐
│                  BACKEND SERVER                            │
│  ┌──────────┐  ┌──────────┐  ┌───────────────────────┐   │
│  │ FastAPI   │  │ SQLAlchemy│  │ Firebase Cloud        │   │
│  │ REST API  │  │ (SQLite)  │  │ Messaging (Push)     │   │
│  └──────────┘  └──────────┘  └───────────────────────┘   │
└──────────────────────────────────────────────────────────┘
                        │
            ┌───────────┼───────────┐
            ▼                       ▼
  ┌──────────────────┐   ┌──────────────────┐
  │  Telegram Bot     │   │  MSDS Console    │
  │  (python-telegram) │   │  (HTML/JS)      │
  └──────────────────┘   └──────────────────┘
```

> **[PLACEHOLDER: Replace the ASCII diagram above with a proper architecture diagram created in draw.io, Lucidchart, or similar tool. Export as PNG and include in the report.]**

### 4.2 Use Case Diagram

> **[PLACEHOLDER: Insert Use Case Diagram here]**
>
> **Actors:**
> - Mobile User (primary)
> - Telegram User
> - System Administrator
>
> **Use Cases:**
> - Check message for spam (manual)
> - Check message for sensitive data (manual)
> - Enable real-time SMS monitoring
> - Enable clipboard monitoring
> - View alert history
> - Scan Gmail inbox
> - Open Telegram bot
> - Read security handbook
> - Configure notification settings
> - Register device for push notifications
> - View detection statistics
>
> **Create this using draw.io, StarUML, or Visual Paradigm.**

### 4.3 Class Diagrams

#### 4.3.1 Backend Class Diagram

> **[PLACEHOLDER: Insert Backend Class Diagram here]**
>
> **Key classes:**
> - `SpamClassifier` — train(), predict(), predict_batch(), save(), load(), evaluate(), cross_validate()
> - `TextPreprocessor` — preprocess(), preprocess_batch()
> - `DLPDetector` — analyze(), redact_text(), _validate_luhn(), _mask_text()
> - `MSDSEvaluator` — evaluate_single(), calculate_msds(), calculate_traditional_metrics(), generate_report()
> - `Alert` (SQLAlchemy model) — id, user_id, alert_type, source, message_preview, full_message, is_spam, spam_confidence, has_sensitive_data, dlp_sensitivity_level, timestamp
> - `UserDevice` (SQLAlchemy model) — id, user_id, device_token, platform

#### 4.3.2 Flutter App Class Diagram

> **[PLACEHOLDER: Insert Flutter Class Diagram here]**
>
> **Key classes:**
> - `LocalSpamClassifier` — loadModel(), predict(), _preprocess(), _generateNgrams(), _computeTfidf(), _sigmoid()
> - `LocalDLPDetector` — analyze(), redactText(), _validateLuhn(), _maskText()
> - `LocalInferenceService` — initialize(), checkSpam(), checkDLP(), redactText(), isBackendAvailable()
> - `ApiService` — checkSpam(), checkDLP(), registerDevice(), getAlerts(), getStats(), healthCheck()
> - `SmsMonitorService` — startMonitoring(), stopMonitoring(), scanExistingSms()
> - `ClipboardMonitorService` — startMonitoring(), stopMonitoring(), checkText()
> - `NotificationService` — initialize(), showSpamAlert(), showDLPAlert()
> - `GmailService` — signIn(), signOut(), fetchRecentEmails()

### 4.4 Entity Relationship Diagram

> **[PLACEHOLDER: Insert ER Diagram here]**
>
> **Tables:**
> - `alerts` — PK: id, FK: user_id → user_devices.user_id
>   - id (INTEGER, PK, AUTO)
>   - user_id (VARCHAR)
>   - device_token (VARCHAR, nullable)
>   - alert_type (VARCHAR — 'spam' or 'dlp')
>   - source (VARCHAR — 'sms', 'email', 'telegram')
>   - direction (VARCHAR — 'inbound' or 'outbound')
>   - message_preview (TEXT — redacted)
>   - full_message (TEXT — redacted for DLP)
>   - is_spam (BOOLEAN, nullable)
>   - spam_confidence (FLOAT, nullable)
>   - spam_risk_level (VARCHAR, nullable)
>   - has_sensitive_data (BOOLEAN, nullable)
>   - dlp_sensitivity_level (VARCHAR, nullable)
>   - dlp_categories (TEXT/JSON, nullable)
>   - dlp_matches (TEXT/JSON, nullable — redacted)
>   - sender (VARCHAR, nullable)
>   - recipient (VARCHAR, nullable)
>   - timestamp (DATETIME)
>   - notification_sent (BOOLEAN)
>   - user_action (VARCHAR, nullable — 'allowed', 'blocked', 'reported')
>
> - `user_devices` — PK: id, UNIQUE: device_token
>   - id (INTEGER, PK, AUTO)
>   - user_id (VARCHAR)
>   - device_token (VARCHAR, UNIQUE)
>   - platform (VARCHAR — 'android', 'ios')
>   - created_at (DATETIME)
>   - last_active (DATETIME)

### 4.5 Sequence Diagrams

#### 4.5.1 Spam Detection Flow

> **[PLACEHOLDER: Insert Sequence Diagram here]**
>
> **Flow:**
> 1. User → SpamCheckScreen: enters message, taps "Check for Spam"
> 2. SpamCheckScreen → LocalInferenceService: checkSpam(message, source)
> 3. LocalInferenceService → LocalSpamClassifier: predict(message)
> 4. LocalSpamClassifier: _preprocess() → _generateNgrams() → _computeTfidf() → _sigmoid()
> 5. LocalSpamClassifier → LocalInferenceService: {is_spam, confidence, risk_level}
> 6. LocalInferenceService → SpamCheckScreen: result
> 7. SpamCheckScreen → User: displays result card (green=safe, red=spam)
> 8. [Optional] LocalInferenceService → ApiService: sync to backend (fire-and-forget)

#### 4.5.2 DLP Check Flow

> **[PLACEHOLDER: Insert Sequence Diagram here]**
>
> **Flow:**
> 1. User → DLPCheckScreen: enters outgoing message, taps "Check Before Sending"
> 2. DLPCheckScreen → LocalInferenceService: checkDLP(message)
> 3. LocalInferenceService → LocalDLPDetector: analyze(message)
> 4. LocalDLPDetector: runs regex patterns → Luhn validation → deduplication → masking
> 5. LocalDLPDetector → LocalInferenceService: {has_sensitive_data, categories, matches, recommendation}
> 6. LocalInferenceService → DLPCheckScreen: result
> 7. IF sensitive data: DLPCheckScreen → User: warning dialog with "Cancel Send" / "Send Anyway"
> 8. IF safe: DLPCheckScreen → User: safe confirmation dialog
> 9. User → DLPCheckScreen: decision (cancel/proceed)
> 10. DLPCheckScreen → ApiService: log decision (redacted) to backend

### 4.6 Component Design

#### 4.6.1 Spam Classifier

- **Algorithm:** TF-IDF (8,000 features, trigrams) + Logistic Regression (balanced class weights)
- **Training data:** 6,487 messages (UCI + Sri Lankan)
- **Deployment:** Exported as JSON (vocabulary + IDF weights + regression coefficients), loaded from app assets
- **Inference:** Native Dart implementation — tokenization, TF-IDF computation, dot product, sigmoid

#### 4.6.2 DLP Engine

- **Approach:** Pattern-based detection using regular expressions
- **Categories (15+):** Credit card (Visa/MC/Amex/Discover with Luhn), bank account (IBAN, local), CVV, SSN, NIC (Sri Lankan old 9+V/X and new 12-digit), NRIC (Singapore), passport, driver's license, password, PIN, OTP, API key (AWS/Bearer/generic), phone (Sri Lankan +94/07x, US, international), email, address, DOB, medical records, IP address
- **Sensitivity levels:** Critical, High, Medium, Low, None
- **Key features:** Luhn checksum validation, context-aware patterns (require keywords), flexible delimiters (`:`, `=`, `is`), per-pattern case sensitivity

#### 4.6.3 MSDS Evaluator

- **Input:** Test cases with expected labels, platform, and category
- **Processing:** Runs DLP detection, calculates TP/FP/FN/TN, applies platform factors and context penalties
- **Output:** MSDS score, traditional metrics, per-platform breakdown, category detection rates, detailed results

### 4.7 Technology Stack

*Table 4.1: Technology Stack*

| Layer | Technology | Version | Purpose |
|-------|-----------|---------|---------|
| Mobile App | Flutter (Dart) | 3.2.6+ | Cross-platform UI |
| UI Framework | Material 3 | Latest | Modern Android design |
| Local ML | Custom Dart TF-IDF | — | On-device spam inference |
| Local DLP | Dart RegExp | — | On-device sensitive data detection |
| Backend API | FastAPI (Python) | 0.104.1 | REST API server |
| ML Training | scikit-learn | 1.3.2 | Model training and evaluation |
| Database | SQLAlchemy + SQLite | 2.0.23 | Alert storage |
| Push Notifications | Firebase Cloud Messaging | 6.2.0 | Real-time alerts |
| Telegram Bot | python-telegram-bot | 21.0 | Chat-based analysis |
| Gmail Integration | Google Sign-In + Gmail API | 6.1.6 | Email scanning |
| SMS Access | Telephony (Flutter) | 0.2.0 | SMS reading and monitoring |
| Permissions | permission_handler | 11.1.0 | Runtime permissions |
| Local Notifications | flutter_local_notifications | 16.3.0 | Spam/DLP alert notifications |
| Persistent Storage | shared_preferences | 2.2.2 | Device user ID, settings |

### 4.8 API Design

*Table 4.2: API Endpoint Specifications*

| Method | Endpoint | Description | Auth |
|--------|----------|-------------|------|
| GET | `/` | Health check + model status | None |
| GET | `/health` | Simple health check | None |
| POST | `/api/v1/spam/check` | Full spam check with logging | user_id |
| POST | `/api/v1/spam/simple-check` | Quick spam check (web console) | None |
| POST | `/api/v1/dlp/check` | Full DLP check with redacted logging | user_id |
| POST | `/api/v1/dlp/simple-check` | Quick DLP check (web console) | None |
| POST | `/api/v1/device/register` | Register device for push notifications | user_id |
| GET | `/api/v1/alerts` | Get alert history (paginated, filterable) | user_id |
| GET | `/api/v1/alerts/{id}` | Get alert detail | user_id |
| PUT | `/api/v1/alerts/{id}` | Update user action (allow/block/report) | user_id |
| GET | `/api/v1/stats/{user_id}` | Get detection statistics | user_id |
| GET | `/api/v1/msds/evaluate` | Run MSDS evaluation | None |
| GET | `/api/v1/msds/info` | MSDS metric information | None |
| GET | `/msds` | MSDS web console (HTML) | None |

### 4.9 Data Flow

**Inbound message (spam detection):**
1. SMS received → Android Telephony API triggers listener
2. Message text passed to LocalSpamClassifier (on-device)
3. TF-IDF features extracted → Logistic Regression prediction (<5ms)
4. If spam: local notification displayed immediately
5. Result optionally synced to backend for logging (non-blocking)

**Outbound message (DLP check):**
1. User pastes message in DLP check screen (or clipboard detected)
2. LocalDLPDetector runs regex patterns locally (instant)
3. If sensitive data found: warning dialog with masked preview and recommendation
4. User chooses "Cancel Send" or "Send Anyway"
5. Decision logged (redacted) to backend if available

### 4.10 Security Design Decisions

*Table 4.4: Security Design Decisions*

| Decision | Rationale | Implementation |
|----------|-----------|---------------|
| On-device inference | Messages never leave the device | TF-IDF + LogReg in Dart, DLP regex in Dart |
| Redacted storage | Backend stores masked versions of sensitive data | `redact_text()` replaces matched text with masks before DB write |
| No hardcoded credentials | Telegram bot token via environment variable | `os.getenv("TELEGRAM_BOT_TOKEN")` |
| Persistent device UUID | Replaces hardcoded user IDs | Generated once via `shared_preferences`, persisted across sessions |
| CORS configured | API accessible from web console | `allow_origins=["*"]` — should be restricted in production |
| Input validation | Pydantic models validate all API inputs | Request/Response models with type checking |

---

## Chapter 5: Implementation

### 5.1 Backend Implementation

#### 5.1.1 Spam Classifier Training

The spam classifier was implemented in Python using scikit-learn. The training pipeline consists of:

1. **Text Preprocessing** (`TextPreprocessor` class):
   - Lowercase conversion
   - URL replacement with `urllink` placeholder token
   - Email replacement with `emailaddr` placeholder
   - Phone number normalization with `phonenumber` placeholder
   - Currency amount normalization with `moneysymbol` placeholder
   - Number replacement with `number` placeholder
   - Repeated punctuation encoding (e.g., "!!!" → `multiplebang`, "???" → `multiplequestion`)
   - Punctuation removal and whitespace normalization

2. **Feature Extraction:**
   - TF-IDF vectorization with 8,000 features
   - Unigram to trigram range (1,3) — captures spam phrases like "click here now"
   - Sublinear TF scaling (logarithmic term frequency)
   - Minimum document frequency of 2 (reduces noise from rare words)
   - Maximum document frequency of 0.95 (removes overly common words)

3. **Classification:**
   - Logistic Regression with C=1.0, balanced class weights, max 1,000 iterations
   - 5-fold stratified cross-validation for robust evaluation
   - Model comparison function benchmarks NB vs LogReg vs LinearSVC

The model was trained in three progressive stages:
- Stage 1: UCI-only (5,572 messages) — 98.4% benchmark, **61.1% real-world**
- Stage 2: + Sri Lankan v1 (6,302 messages) — 98.7% benchmark, **89.3% real-world**
- Stage 3: + Singlish/Sinhala expanded (6,487 messages) — 98.0% benchmark, **96.7% real-world**

#### 5.1.2 DLP Engine

The DLP engine (`dlp_detector.py`) uses compiled regular expressions organized by category. Key implementation details:

- **Per-pattern case sensitivity:** Each pattern uses inline `(?i)` only where needed, preventing the SWIFT/BIC pattern `[A-Z]{4}[A-Z]{2}[A-Z0-9]{2}` from matching ordinary English words like "tomorrow" when global `re.IGNORECASE` was active
- **Luhn validation:** Credit card matches are validated using the Luhn checksum algorithm to reject random 16-digit numbers
- **Context requirements:** Patterns for ambiguous data (bank accounts, PINs, passwords) require contextual keywords (e.g., "account", "pin", "password")
- **Flexible delimiters:** Patterns accept `:`, `=`, and `is` as delimiters (e.g., "PIN: 1234", "PIN is 1234", "pin=1234")
- **Sri Lankan patterns:** NIC old format (9 digits + V/X), NIC new format (12 digits starting 19xx/20xx), phone (+94 XX XXX XXXX, 07XXXXXXXX)
- **Text redaction:** `redact_text()` method replaces detected sensitive data with masked versions for safe storage

#### 5.1.3 FastAPI Backend

The backend (`main.py`) provides REST API endpoints with:
- CORS middleware for cross-origin access
- SQLAlchemy ORM for database operations
- Pydantic models for request/response validation
- Background task execution for push notifications
- Lifespan handler for ML model loading on startup
- Redacted storage for DLP alerts — raw sensitive data is never persisted

#### 5.1.4 Telegram Bot

The Telegram bot (`telegram_bot.py`) provides:
- `/start` — Welcome message and usage instructions
- `/help` — Detailed help information
- `/spam <message>` — Dedicated spam checking
- `/dlp <message>` — Dedicated sensitive data checking
- `/about` — Project information
- `/feedback` — User feedback submission
- Direct message forwarding — analyzes both spam and DLP simultaneously
- Error handling with user-friendly error messages

### 5.2 Mobile Application Implementation

#### 5.2.1 Local Inference

The on-device spam classifier (`local_spam_classifier.dart`) implements TF-IDF + Logistic Regression inference in pure Dart:

1. Load model JSON from Flutter assets (472 KB)
2. Parse vocabulary map (8,000 word → index entries)
3. Parse IDF weights, regression coefficients, and intercept
4. For each prediction:
   a. Preprocess text (matching Python preprocessing exactly)
   b. Generate unigrams, bigrams, and trigrams
   c. Compute sparse TF-IDF vector using vocabulary lookup
   d. L2-normalize the vector
   e. Calculate dot product with coefficient vector + intercept
   f. Apply sigmoid function for spam probability

The DLP detector (`local_dlp_detector.dart`) ports all Python regex patterns to Dart `RegExp`, maintaining identical detection behavior including Luhn validation and text masking.

The `LocalInferenceService` provides a unified interface:
- Generates and persists a device UUID via `shared_preferences`
- Routes spam checks to local classifier, with optional backend sync
- Routes DLP checks to local detector (always local, instant)
- Handles graceful fallback when backend is unavailable

#### 5.2.2 SMS Monitoring

Real-time SMS monitoring uses the Android Telephony API via the `telephony` Flutter package:
- **Foreground:** `listenIncomingSms` with callback to local spam classifier + DLP detector
- **Background:** `backgroundMessageHandler` entry point for processing when app is not focused
- Both spam and DLP checks run locally — no network required
- Spam SMS triggers local notification with sender and risk level
- Scanned messages displayed in Protection Screen's recent alerts

#### 5.2.3 Clipboard Monitoring

The clipboard monitor polls every 3 seconds while the app is in the foreground:
- Uses `Clipboard.getData()` to check for new content
- Runs local DLP detection (no network needed)
- Only notifies for high/critical sensitivity matches
- Tracks `AppLifecycleState` to pause when app is backgrounded

#### 5.2.4 Gmail Integration

Gmail scanning uses Google OAuth 2.0 via the `google_sign_in` package:
- Requests `gmail.readonly` scope
- Fetches recent inbox messages via Gmail API
- Extracts plain text body (handles multipart MIME)
- Sends content through local spam + DLP analysis

### 5.3 Model Export and Deployment

A custom export script (`export_model.py`) extracts model parameters from the scikit-learn pipeline:
- TF-IDF vocabulary (word → index mapping, 8,000 entries)
- IDF weights array (8,000 floats)
- Logistic Regression coefficients (8,000 floats) and intercept (1 float)
- Classification thresholds (high: 0.8, medium: 0.5, low: 0.3)

These are serialized to a single JSON file (472 KB) and included as a Flutter asset, enabling fully offline inference with no framework dependencies.

### 5.4 Application Screenshots

> **[PLACEHOLDER: Screenshots — take these from the running app]**

#### Figure 5.1: Splash Screen
> **[INSERT SCREENSHOT: Splash screen showing Sifitlier logo, "AI-Powered Security" tagline, and loading indicator. Shows "Loading AI models..." then "Connected!" or "Offline mode — AI running locally"]**

#### Figure 5.2: Dashboard Screen
> **[INSERT SCREENSHOT: Main dashboard showing welcome card, security overview stats (Spam Blocked, DLP Warnings, Total Alerts), quick action buttons, Secure Channels section, and features grid]**

#### Figure 5.3: Spam Check — Input
> **[INSERT SCREENSHOT: Spam detection screen with source selector (SMS/Email/Telegram), sender field, message text area, and "Check for Spam" button]**

#### Figure 5.4: Spam Check — Spam Detected
> **[INSERT SCREENSHOT: Result card showing red "HIGH RISK SPAM" header with spam probability, confidence, and risk level]**

#### Figure 5.5: Spam Check — Safe Message
> **[INSERT SCREENSHOT: Result card showing green "LOOKS SAFE" header with low spam probability]**

#### Figure 5.6: DLP Check — Input
> **[INSERT SCREENSHOT: Outgoing Message Guard screen with info card, source selector, recipient field, message area, and "Check Before Sending" button]**

#### Figure 5.7: DLP Check — Warning Dialog
> **[INSERT SCREENSHOT: Warning dialog showing detected categories (e.g., CREDIT_CARD, PASSWORD), sensitivity level, recommendation, and "Cancel Send" / "Send Anyway" buttons]**

#### Figure 5.8: DLP Check — Safe Result
> **[INSERT SCREENSHOT: Green "Safe to Send!" dialog confirming no sensitive data detected]**

#### Figure 5.9: Real-Time Protection Screen
> **[INSERT SCREENSHOT: Protection screen showing status card (green "Protection Active"), SMS Monitoring toggle, Clipboard Monitoring toggle, "Scan Existing SMS Inbox" button, and Recent Alerts list]**

#### Figure 5.10: Alert History
> **[INSERT SCREENSHOT: Logs screen with tabs (All/Spam/DLP), showing alert cards with type, source icon, timestamp, and message preview]**

#### Figure 5.11: Security Handbook
> **[INSERT SCREENSHOT: Handbook screen showing chapter navigation (Understanding Spam, Recognizing Phishing, Protecting Your Data, Safe Messaging, Platform Tips) with expandable sections]**

#### Figure 5.12: Settings Screen
> **[INSERT SCREENSHOT: Settings screen with server connection status, notification toggles, about section, and clear data option]**

#### Figure 5.13: Gmail Connect Screen
> **[INSERT SCREENSHOT: Gmail integration screen with Google Sign-In button, connected account info, and email scanning functionality]**

#### Figure 5.14: Telegram Bot — Welcome
> **[INSERT SCREENSHOT: Telegram bot showing /start welcome message with feature description and command list]**

#### Figure 5.15: Telegram Bot — Spam Result
> **[INSERT SCREENSHOT: Bot response showing "SPAM DETECTED!" with risk level, confidence, and spam probability]**

#### Figure 5.16: Telegram Bot — DLP Result
> **[INSERT SCREENSHOT: Bot response showing "SENSITIVE DATA DETECTED!" with sensitivity level, categories, and recommendation]**

#### Figure 5.17: MSDS Web Console
> **[INSERT SCREENSHOT: Browser showing the MSDS web console at /msds with spam check, DLP check, and MSDS evaluation tabs]**

---

## Chapter 6: Testing and Evaluation

### 6.1 Spam Classifier Evaluation

#### 6.1.1 Benchmark Results (5-fold Cross-Validation)

*Table 6.1: Benchmark Results*

| Metric | Score |
|--------|-------|
| Accuracy | 98.6% (+/- 0.46%) |
| Precision | 94.7% |
| Recall | 94.7% |
| F1 Score | 94.7% |

#### 6.1.2 Confusion Matrix (20% holdout test set)

*Table 6.3: Confusion Matrix*

|  | Predicted Ham | Predicted Spam |
|--|---------------|----------------|
| **Actual Ham** | 1,042 (TN) | 13 (FP) |
| **Actual Spam** | 13 (FN) | 230 (TP) |

Total test samples: 1,298. Test accuracy: 98.0%.

> **[PLACEHOLDER: Insert Figure 6.1 — visual confusion matrix heatmap. Can create using matplotlib or Excel.]**

#### 6.1.3 Model Comparison

*Table 6.2: Model Comparison (5-fold CV on UCI dataset)*

| Model | Accuracy | Precision | Recall | F1 |
|-------|----------|-----------|--------|-----|
| Multinomial Naive Bayes | 98.67% | 97.87% | 92.10% | 94.89% |
| **Logistic Regression (selected)** | **98.56%** | **94.55%** | **94.78%** | **94.66%** |
| LinearSVC | 98.53% | 94.40% | 94.50% | 94.45% |

Logistic Regression was selected for its superior recall (94.78% vs 92.10%) — catching more spam is prioritized over marginally higher precision, as missed spam (false negatives) has greater real-world impact than false alarms.

#### 6.1.4 Real-World Sri Lankan SMS Validation

*Table 6.4: Real-World SMS Test Results (30 messages)*

| # | Message (truncated) | Expected | Predicted | Prob | Correct |
|---|---------------------|----------|-----------|------|---------|
| 1 | Rs.100,000 loan scam (Singlish + URL) | Spam | Spam | 88.6% | Yes |
| 2 | Rs.250,000 loan scam (Singlish + URL) | Spam | Spam | 90.2% | Yes |
| 3 | Mobitel device promo (Sinhala) | Spam | Spam | 79.2% | Yes |
| 4 | Dialog YouTube pack promo | Spam | Spam | 90.6% | Yes |
| 5 | Mobitel reload promo | Spam | Spam | 92.1% | Yes |
| 6 | Pizza Hut MEGA MONDAY 50% OFF | Spam | Spam | 88.6% | Yes |
| 7 | Chinese Dragon Cafe 50% OFF | Spam | Spam | 82.7% | Yes |
| 8 | Glomark + Sampath card promo | Spam | Spam | 83.5% | Yes |
| 9 | ESOFT predict & win (short) | Spam | Spam | 75.8% | Yes |
| 10 | ESOFT career promo (short) | Spam | Spam | 72.9% | Yes |
| 11 | Sinhala loan scam (Vegavat saha pahasu) | Spam | Spam | 87.0% | Yes |
| 12 | Mobitel smart loan promo (Sinhala) | Spam | Spam | 95.9% | Yes |
| 13 | Uber ride arriving (Driver: Kasun) | Ham | Ham | 21.5% | Yes |
| 14 | PickMe ride accepted | Ham | Ham | 19.9% | Yes |
| 15 | Daraz order shipped | Ham | Ham | 13.3% | Yes |
| 16 | Keells receipt (Rs.3,450, points) | Ham | Ham | 35.3% | Yes |
| 17 | BOC account credited Rs.50,000 | Ham | Ham | 34.9% | Yes |
| 18 | Sampath card charged Rs.12,500 | Ham | Ham | 25.5% | Yes |
| 19 | HNB FD maturity notice | Ham | Ham | 32.8% | Yes |
| 20 | Singlish: "oya exam eka kohomada?" | Ham | Ham | 9.4% | Yes |
| 21 | Singlish: "machang 6.30 ta ena..." | Ham | **Spam** | 65.1% | **No** |
| 22 | Uni: "Lab cancelled tomorrow" | Ham | Ham | 14.7% | Yes |
| 23 | Student: "send me the notes" | Ham | Ham | 8.1% | Yes |
| 24 | Birthday wish | Ham | Ham | 19.8% | Yes |
| 25 | Family: "Mom wants to know..." | Ham | Ham | 12.6% | Yes |
| 26 | Grama Niladhari electoral notice | Ham | Ham | 13.9% | Yes |
| 27 | Pizza Hut order confirmed (receipt) | Ham | Ham | 28.0% | Yes |
| 28 | BOC OTP (391847) | Ham | Ham | 23.6% | Yes |
| 29 | NIC Office collection notice | Ham | Ham | 21.7% | Yes |
| 30 | Keells Nexus profile reminder | Ham | Ham | 25.3% | Yes |

**Results:**

| Category | Messages | Correct | Accuracy |
|----------|----------|---------|----------|
| Spam (scams, promos) | 12 | 12 | **100%** |
| Ham (alerts, personal, govt) | 18 | 17 | **94.4%** |
| **Total** | **30** | **29** | **96.7%** |

The single misclassification (#21) was a very short Singlish message "machang 6.30 ta ena. late unoth call karanna" — only 8 words with a number (6.30), which the TF-IDF model interprets as suspicious due to limited context.

#### 6.1.5 Training Progression

*Table 6.5: Training Progression*

| Stage | Training Data | Benchmark | Real-World SL | Key Improvement |
|-------|--------------|-----------|---------------|-----------------|
| Stage 1: English only | 5,572 (UCI) | 98.4% | **61.1%** | Baseline |
| Stage 2: + SL data v1 | 6,302 | 98.7% | **89.3%** | Bank/ride/receipt alerts now correct |
| Stage 3: + Singlish expanded | 6,487 | 98.0% | **96.7%** | ESOFT promos + Singlish casual now correct |

> **[PLACEHOLDER: Insert Figure 6.2 — bar chart or line graph showing the 3-stage progression. Create using matplotlib, Excel, or Google Sheets.]**

This demonstrates that **benchmark accuracy alone is insufficient** for evaluating real-world performance. The model required locale-specific training data to perform adequately in the target environment. Stage 1 had 98.4% benchmark accuracy but only 61.1% on real Sri Lankan messages — a 37% gap that was closed through iterative dataset expansion.

### 6.2 DLP Engine Evaluation

#### 6.2.1 Development Dataset (115 cases)

| Metric | Score |
|--------|-------|
| Precision | 1.00 |
| Recall | 1.00 |
| F1 Score | 1.00 |
| Accuracy | 1.00 |
| MSDS Score | 1.06 |
| False Positives | 0 |

#### 6.2.2 Per-Platform Breakdown

*Table 6.6: DLP Per-Platform Performance*

| Platform | Tests | Accuracy | Precision | Recall | F1 |
|----------|-------|----------|-----------|--------|-----|
| SMS | 50 | 1.00 | 1.00 | 1.00 | 1.00 |
| Email | 35 | 1.00 | 1.00 | 1.00 | 1.00 |
| Telegram | 30 | 1.00 | 1.00 | 1.00 | 1.00 |

> **[PLACEHOLDER: Insert Figure 6.4 — grouped bar chart showing per-platform performance]**

#### 6.2.3 Independent Validation (54 cases)

A completely separate dataset with Sri Lankan bank OTPs (BOC, Sampath, HNB, NTB, Cargills), Singlish messages, carrier notifications, and local service messages:

| Metric | Initial Run | After Fix |
|--------|-------------|-----------|
| Accuracy | 98.1% | 100% |
| FN | 1 (BOC OTP pattern) | 0 |

The initial validation discovered a missed OTP pattern: "Your OTP for online banking is 391847" — the OTP pattern required the code to immediately follow the keyword, but in this message, "for online banking" appeared between "OTP" and the code. A more flexible pattern was added to handle up to 4 intervening words.

This demonstrates the value of independent validation — the development dataset did not contain this pattern variation.

#### 6.2.4 Category Coverage

*Table 6.7: DLP Category Detection Rates*

| Category | Test Cases | Detection Rate | Example |
|----------|-----------|----------------|---------|
| Password | 14 | 100% | "password: admin123!" |
| Credit Card | 6 | 100% | "4532015112830366" (Luhn valid) |
| NIC (Sri Lankan) | 6 | 100% | "901234567V", "199912345678" |
| OTP | 6 | 100% | "OTP is 456789" |
| Phone | 8 | 100% | "+94 77 123 4567", "0771234567" |
| Bank Account | 6 | 100% | "Account number: 12345678901234" |
| PIN | 3 | 100% | "PIN is 1234" |
| Email | 4 | 100% | "john@example.com" |
| SSN | 2 | 100% | "123-45-6789" |
| CVV | 2 | 100% | "CVV is 321" |
| DOB | 2 | 100% | "DOB: 15/03/1995" |
| API Key | 3 | 100% | "api_key: sk-1234567890..." |
| IP Address | 1 | 100% | "192.168.1.100" |
| Safe (adversarial) | 37 | 100% (0 FP) | "The password to success is hard work" |

### 6.3 MSDS vs Traditional Metrics — Research Comparison

#### 6.3.1 Experiment Design

Three test sets with different difficulty levels were evaluated using the same DLP detector:
- **Set A:** Formal email messages (easy — structured, explicit labels)
- **Set B:** Casual SMS with abbreviations (medium — short, informal)
- **Set C:** Adversarial messages with ambiguous context (hard — trigger words, false positives)

#### 6.3.2 Key Finding

*Table 6.8: MSDS vs F1 Comparison*

| Test Set | F1 Score | MSDS Score | Difference | TP | FP | FN |
|----------|----------|------------|------------|----|----|-----|
| Email (formal) | 1.00 | 0.90 | -0.10 | 8 | 0 | 0 |
| SMS (casual) | 1.00 | 1.20 | +0.20 | 8 | 0 | 0 |
| Adversarial | 0.67 | 0.33 | -0.34 | 3 | 2 | 1 |

> **[PLACEHOLDER: Insert Figure 6.3 — grouped bar chart comparing F1 and MSDS across the three sets. The key visual: F1 shows identical bars for Email and SMS (both 1.0), while MSDS shows different heights (0.9 vs 1.2).]**

#### 6.3.3 Analysis

**F1 gives identical scores (1.00) to email and SMS detection, despite SMS being inherently harder.** MSDS correctly differentiates them:

- **Email MSDS = 0.90:** The platform factor for email is 0.9 (easiest platform). Getting everything right on easy data gets a lower MSDS bonus.
- **SMS MSDS = 1.20:** The platform factor for SMS is 1.2 (hardest platform). Getting everything right on hard data is rewarded.
- **Adversarial MSDS = 0.33 (vs F1 = 0.67):** MSDS penalizes the false positives and missed critical data much more heavily through context penalties.

This demonstrates MSDS provides three insights that F1 cannot:

1. **Platform difficulty:** SMS detection is harder and MSDS rewards systems that handle it well
2. **Severity weighting:** Missing a credit card (penalty=2.0) costs more than missing an email address (penalty=1.0)
3. **Category accuracy:** Detecting "phone" when it's actually "credit card" is penalized (penalty=0.3)

### 6.4 On-Device vs Cloud Inference

*Table 6.9: On-Device vs Cloud Inference Comparison*

| Metric | Local (Dart) | Cloud (API) |
|--------|-------------|-------------|
| Average latency | 0.08 ms/msg | ~150 ms/msg |
| Speedup | **1,849x** | baseline |
| Network required | No | Yes |
| Privacy | Messages stay on device | Messages transmitted to server |
| Offline capable | Yes | No |
| Model size | 472 KB | N/A (server-side) |
| Battery impact | Minimal (CPU only) | Higher (network radio) |

> **[PLACEHOLDER: Insert Figure 6.5 — bar chart showing latency comparison. Use logarithmic scale to show the 1,849x difference clearly.]**

### 6.5 User Acceptance Testing

> **[PLACEHOLDER: If Umasha conducts user testing, add results here. Suggested approach:]**
>
> **Methodology:** [X] participants were asked to forward real SMS messages to the Telegram bot and rate the detection accuracy, usefulness, and ease of use on a 5-point Likert scale.
>
> **Participants:** [X] university students aged 20-25 at IIT Sri Lanka
>
> **Results:**
> | Metric | Average Rating (1-5) |
> |--------|---------------------|
> | Detection accuracy | [X.X] |
> | Usefulness | [X.X] |
> | Ease of use | [X.X] |
> | Privacy confidence | [X.X] |
> | Overall satisfaction | [X.X] |
>
> **If no user testing was conducted, write:**
> User acceptance testing was not conducted within the project timeline. This is acknowledged as a limitation and recommended for future work (Section 7.5).

### 6.6 Evaluation Summary

*Table 6.10: Complete Evaluation Summary*

| Component | Metric | Result | Objective |
|-----------|--------|--------|-----------|
| Spam (benchmark) | CV Accuracy | 98.6% | O1: >95% |
| Spam (real-world) | Accuracy on 30 SL messages | **96.7%** | O1: >95% |
| Spam catch rate | Spam detected correctly | **100%** (12/12) | — |
| DLP (development) | F1 on 115 cases | **1.00** | O2 |
| DLP (independent) | F1 on 54 cases | **1.00** | O2 |
| DLP categories | Sensitive data types | **15+** | O2: 10+ |
| On-device latency | Inference time | **<1 ms** | O3: <5ms |
| On-device model size | JSON file | **472 KB** | O3: <500KB |
| MSDS vs F1 | Demonstrated divergence | **Yes** (Table 6.8) | O4 |
| Multi-platform | SMS, Email, Telegram | **All working** | O5 |

**All five objectives met or exceeded.**

---

## Chapter 7: Conclusion and Future Work

### 7.1 Summary of Achievements

This project successfully developed Sifitlier, an AI-powered mobile security application that addresses three key gaps identified in the literature:

1. **Multilingual spam detection:** By combining the UCI English dataset with a custom Sri Lankan SMS dataset (including Singlish and Sinhala messages), the classifier achieves 96.7% accuracy on real-world Sri Lankan messages — compared to 61.1% with English-only training. The spam catch rate is 100%.

2. **Consumer mobile DLP:** A comprehensive DLP engine detects 15+ categories of sensitive data with perfect precision and recall on 115 + 54 test cases, including Sri Lankan-specific identifiers (NIC, local phone formats, bank OTPs).

3. **MSDS evaluation metric:** The proposed Mobile Sensitivity Detection Score provides platform-aware, severity-weighted evaluation that captures insights inaccessible to traditional F1 scores — specifically, that SMS detection is inherently harder than email, and that missing critical data should be penalized more heavily.

Additionally, the on-device inference architecture ensures user privacy by keeping all message analysis local, with 1,849x latency improvement over cloud-based alternatives.

### 7.2 Contribution to Knowledge

The primary contributions of this work are:

1. **MSDS Metric:** A novel evaluation metric for mobile DLP systems that incorporates platform difficulty factors and severity-weighted penalties, demonstrated to provide insights that F1 cannot (Section 6.3).

2. **On-device privacy-preserving inference:** Demonstration that a full spam + DLP pipeline can run on a mobile device with a 472 KB model and <5ms inference time, eliminating the privacy contradiction inherent in cloud-based mobile security (Section 6.4).

3. **Sri Lankan SMS dataset and evaluation:** The first (to our knowledge) labeled Singlish/Sinhala SMS dataset for spam detection, along with cross-platform DLP evaluation including Sri Lankan-specific sensitive data categories (Section 3.5).

### 7.3 Objectives Achievement Matrix

| Objective | Target | Achieved | Evidence |
|-----------|--------|----------|----------|
| O1: Multilingual spam classifier | >95% real-world accuracy | **96.7%** | Table 6.4 |
| O2: DLP with 10+ categories | 10+ SL-specific categories | **15+ categories** | Table 6.7 |
| O3: On-device inference | <5ms, <500KB | **<1ms, 472KB** | Table 6.9 |
| O4: MSDS metric validation | Demonstrate F1 divergence | **F1=1.0, MSDS=0.9-1.2** | Table 6.8 |
| O5: Multi-platform deployment | SMS, Email, Telegram | **All deployed** | Chapter 5 |

### 7.4 Limitations

1. **Short Singlish messages:** Very short messages (<10 words) with numeric content remain challenging for the TF-IDF model due to limited contextual features. A single Singlish message was misclassified in real-world testing (1/30).

2. **Pure Sinhala representation:** The training dataset has limited pure Sinhala Unicode text (~10 messages). Expanding this would improve detection of Sinhala-only spam.

3. **Static model:** The on-device model cannot be updated without releasing a new app version. Over-the-air model updates would enable continuous improvement.

4. **No message metadata:** The classifier uses only message text, ignoring metadata such as sender number, time of day, and message frequency that could improve classification.

5. **Android only:** SMS monitoring is limited to Android due to iOS API restrictions on SMS access.

6. **No user study:** The system was evaluated using curated test datasets and real messages from the researcher. A broader user study with diverse participants would strengthen the evaluation.

7. **Constructed Sri Lankan corpus:** While based on observed real-world messaging patterns and validated through annotation review, the Sri Lankan training corpus was constructed through systematic synthesis rather than collected directly from user message logs due to privacy constraints. Future work could employ crowdsourced data collection with informed consent to build a larger, more representative corpus.

### 7.5 Future Work

1. **Transformer-based models:** Fine-tuning a multilingual BERT or XLM-RoBERTa model on the Sri Lankan dataset could significantly improve handling of code-switching, at the cost of a larger model (~100MB+). Knowledge distillation (Hinton et al., 2015) could compress this for mobile deployment.

2. **User study:** A field evaluation with 20-30 real users forwarding actual messages through the system would provide ecological validity beyond laboratory testing.

3. **Federated learning:** Training on user-contributed data without centralizing it would expand the dataset while preserving privacy — aligning with the project's privacy-first philosophy.

4. **iOS support:** Adapting the DLP and clipboard monitoring features for iOS, where SMS access is more restricted but clipboard and notification APIs are available.

5. **Image-based spam detection:** Extending detection to image-based spam (screenshots of messages, promotional images) using OCR and image classification.

6. **Sinhala NLP corpus:** Building a comprehensive Sinhala/Singlish SMS corpus as a public dataset would benefit the broader NLP research community.

7. **Over-the-air model updates:** Implementing model versioning and background downloads would allow the spam classifier to improve without requiring app store updates.

8. **Sender reputation:** Incorporating sender number/address reputation from community reports could improve classification of messages from known spam sources.

### 7.6 Personal Reflection

> **[PLACEHOLDER: Write 200-300 words reflecting on the project experience. Westminster typically requires this. Cover:]**
>
> - What you learned technically (ML, Flutter, system design)
> - Challenges faced (Singlish model accuracy, DLP false positives, on-device deployment)
> - How you overcame them (iterative training, independent validation, model export)
> - Skills developed (Python, Dart, research methodology)
> - What you would do differently
> - How this experience prepares you for your career

---

## References

Almeida, T.A., Hidalgo, J.M.G. and Yamakami, A. (2011) 'Contributions to the study of SMS spam filtering: new collection and results', *Proceedings of the 11th ACM Symposium on Document Engineering*, pp. 259-262. Available at: https://archive.ics.uci.edu/dataset/228/sms+spam+collection (Accessed: March 2026).

Alneyadi, S., Sithirasenan, E. and Muthukkumarasamy, V. (2016) 'A survey on data leakage prevention systems', *Journal of Network and Computer Applications*, 62, pp. 137-152.

Androutsopoulos, I., Koutsias, J., Chandrinos, K.V. and Spyropoulos, C.D. (2000) 'An experimental comparison of naive Bayesian and keyword-based anti-spam filtering with personal e-mail messages', *Proceedings of the 23rd ACM SIGIR Conference*, pp. 160-167.

Barbedillo, D. (2024) *SMS Spam Multilingual Collection Dataset*. HuggingFace. Available at: https://huggingface.co/datasets/dbarbedillo/SMS_Spam_Multilingual_Collection_Dataset (Accessed: March 2026).

Bourigue, R. (2025) *SMS Spam Dataset*. IEEE DataPort. doi: 10.21227/d0rq-tj46.

Bourigue, R., Ouhbi, B., Frikh, B. and Cohen, A. (2025) 'Key insights into recommended SMS spam detection datasets', *Scientific Reports*, 15, Article 8162. Available at: https://www.nature.com/articles/s41598-025-92223-1 (Accessed: March 2026).

Carvalho, V.R. and Cohen, W.W. (2004) 'Learning to extract signature and reply lines from email', *Proceedings of the Conference on Email and Anti-Spam (CEAS)*.

Cormack, G.V., Hidalgo, J.M.G. and Sanz, E.P. (2007) 'Feature engineering for mobile (SMS) spam filtering', *Proceedings of the 30th ACM SIGIR Conference*, pp. 871-872.

Cortes, C. and Vapnik, V. (1995) 'Support-vector networks', *Machine Learning*, 20(3), pp. 273-297.

De Silva, N. (2019) 'Survey on publicly available Sinhala natural language processing tools and research', *arXiv preprint arXiv:1906.02358*. Available at: https://arxiv.org/abs/1906.02358 (Accessed: March 2026).

Devlin, J., Chang, M.W., Lee, K. and Toutanova, K. (2019) 'BERT: Pre-training of deep bidirectional transformers for language understanding', *Proceedings of NAACL-HLT 2019*, pp. 4171-4186.

Fernandez-Delgado, M., Cernadas, E., Barro, S. and Amorim, D. (2014) 'Do we need hundreds of classifiers to solve real world classification problems?', *Journal of Machine Learning Research*, 15, pp. 3133-3181.

Fernando, S. and Wijeratne, Y. (2020) 'Challenges in Sinhala-English code-switched text processing', *Proceedings of the Workshop on Computational Approaches to Linguistic Code-Switching*.

Hevner, A.R., March, S.T., Park, J. and Ram, S. (2004) 'Design science in information systems research', *MIS Quarterly*, 28(1), pp. 75-105.

Hinton, G., Vinyals, O. and Dean, J. (2015) 'Distilling the knowledge in a neural network', *arXiv preprint arXiv:1503.02531*.

Howard, A.G., Zhu, M., Chen, B., Kalenichenko, D., Wang, W., Weyand, T., Andreetto, M. and Adam, H. (2017) 'MobileNets: Efficient convolutional neural networks for mobile vision applications', *arXiv preprint arXiv:1704.04861*.

ISO (2013) *ISO/IEC 27001:2013 Information technology — Security techniques — Information security management systems*. International Organization for Standardization.

Jamatia, A., Gambäck, B. and Das, A. (2015) 'Part-of-speech tagging for code-mixed English-Hindi Twitter and Facebook chat messages', *Proceedings of the International Conference Recent Advances in Natural Language Processing*, pp. 239-248.

Kim, J., et al. (2025) 'PII-Bench: Evaluating Query-Aware Privacy Protection Systems', *arXiv preprint arXiv:2502.18545*. Available at: https://arxiv.org/abs/2502.18545 (Accessed: March 2026).

Lane, N.D., Georgiev, P. and Qendro, L. (2015) 'DeepEar: Robust smartphone audio sensing in unconstrained acoustic environments using deep learning', *Proceedings of UbiComp 2015*, pp. 283-294.

Luhn, H.P. (1960) 'Computer for verifying numbers', *US Patent 2,950,048*.

Manning, C.D., Raghavan, P. and Schutze, H. (2008) *Introduction to Information Retrieval*. Cambridge University Press.

McCallister, E., Grance, T. and Scarfone, K. (2010) *Guide to Protecting the Confidentiality of Personally Identifiable Information (PII)*, NIST SP 800-122.

Metsis, V., Androutsopoulos, I. and Paliouras, G. (2006) 'Spam filtering with Naive Bayes — which Naive Bayes?', *Proceedings of the 3rd Conference on Email and Anti-Spam (CEAS)*. Available at: https://www.kaggle.com/datasets/wanderfj/enron-spam (Accessed: March 2026).

Pedregosa, F., Varoquaux, G., Gramfort, A., Michel, V., Thirion, B., Grisel, O., Blondel, M., Prettenhofer, P., Weiss, R., Dubourg, V. and Vanderplas, J. (2011) 'Scikit-learn: Machine learning in Python', *Journal of Machine Learning Research*, 12, pp. 2825-2830.

Powers, D.M.W. (2011) 'Evaluation: from precision, recall and F-measure to ROC, informedness, markedness and correlation', *Journal of Machine Learning Technologies*, 2(1), pp. 37-63.

Protecto (2024) *Benchmarking PII Identification in Unstructured Text: A Quantitative Comparison*. Available at: https://www.protecto.ai/download-personal-data-for-testing/ (Accessed: March 2026).

Sokolova, M. and Lapalme, G. (2009) 'A systematic analysis of performance measures for classification tasks', *Information Processing & Management*, 45(4), pp. 427-437.

Sun, C., Qiu, X., Xu, Y. and Huang, X. (2019) 'How to fine-tune BERT for text classification', *China National Conference on Chinese Computational Linguistics*, pp. 194-206.

thehamkercat (2023) *Telegram Spam-Ham Dataset*. HuggingFace. Available at: https://huggingface.co/datasets/thehamkercat/telegram-spam-ham (Accessed: March 2026).

> **[NOTE: Verify all URLs are accessible. Add any additional references from your own literature review. Westminster requires Harvard referencing format — ensure consistency.]**

---

## Appendices

### Appendix A: How to Run

```bash
# Backend setup
cd backend
pip install -r requirements.txt

# Train spam model (combined UCI + Sri Lankan data)
PYTHONIOENCODING=utf-8 python retrain_with_sl_data.py

# Run DLP self-test
python dlp_detector.py

# Run MSDS evaluation (115 test cases)
PYTHONIOENCODING=utf-8 python msds_experiment.py

# Run MSDS vs F1 comparison (research experiment)
PYTHONIOENCODING=utf-8 python msds_research_comparison.py

# Run independent validation (54 cases)
PYTHONIOENCODING=utf-8 python msds_independent_validation.py

# Run real-world spam test (30 messages)
PYTHONIOENCODING=utf-8 python spam_real_world_test.py

# Export model for Flutter app
python export_model.py

# Start backend server
python main.py

# Start Telegram bot (requires TELEGRAM_BOT_TOKEN env var)
python telegram_bot.py

# Flutter app
cd flutter_app
flutter pub get
flutter analyze
flutter run
```

### Appendix B: MSDS Formula Derivation

The MSDS metric extends F1 by incorporating three additional factors:

**Context Weight (Cw):** Measures category-level accuracy.
```
Cw = (correct category detections) / (total positive detections)
```
Range: 0 to 1. If the detector identifies data as "phone" when it's actually "credit card", Cw decreases.

**Platform Factor (Pf):** Weighted average of platform difficulty factors.
```
Pf = Σ(platform_factor × platform_count) / total_count
```
Range: 0.9 to 1.2. SMS-heavy test sets receive higher Pf, rewarding systems that handle the hardest platform.

**Context Penalty (Cp):** Severity-weighted sum of errors.
```
Cp = Σ(penalty_weight × error_count) for each error type
```
Replaces the simple FP + FN denominator in F1 with severity-aware penalties.

**Relationship to F1:** When Cw = 1, Pf = 1, and all penalties equal 1.0 (uniform severity):
```
MSDS = TP / (TP + FP + FN) ≈ F1 (for balanced precision/recall)
```
MSDS reduces to approximately F1 when platform and severity adjustments are neutral.

### Appendix C: Sri Lankan SMS Dataset Categories

| Category | Type | Count | Example |
|----------|------|-------|---------|
| Loan scams | Spam | 60 | "Rs.100,000 k dakwa nayak kalin..." |
| Carrier promos | Spam | 80 | "Dialog: Get 5GB for just Rs.199!" |
| Food promos | Spam | 50 | "Pizza Hut: MEGA MONDAY! 50% OFF" |
| Retail promos | Spam | 50 | "Glomark: 20% OFF with Sampath card" |
| Education spam | Spam | 40 | "ESOFT: Fast-Track your Career!" |
| Short promo spam | Spam | 65 | "Win BIG prizes! Click now!" |
| Singlish scams | Spam | 50 | "Lucky draw winner! Claim karanna" |
| Investment scams | Spam | 35 | "Earn Rs.50,000/day from home!" |
| Phishing | Spam | 35 | "Your account needs verification!" |
| Bank alerts | Ham | 100 | "BOC: Account credited Rs.50,000" |
| OTP messages | Ham | 60 | "HNB: OTP 583201 for payment" |
| Ride apps | Ham | 40 | "Uber arriving. Driver: Kasun" |
| E-commerce | Ham | 40 | "Daraz: Order shipped. Track..." |
| Receipts/bills | Ham | 50 | "Keells: Bill Rs.3,450. Points: 34" |
| Personal (Singlish) | Ham | 130+ | "machang exam eka kohomada?" |
| Personal (Sinhala) | Ham | 10 | "හෙට උදේ 8ට එන්න" |
| Government | Ham | 10 | "Grama Niladhari electoral notice" |
| Appointments | Ham | 20 | "Dr. appointment confirmed 3pm" |

### Appendix D: Project Repository Structure

```
Sifitlier-main/
├── CHANGES.md                         # Detailed changelog of all improvements
├── TRAINING_REPORT.md                 # 3-stage training progression report
├── backend/
│   ├── main.py                        # FastAPI server
│   ├── dlp_detector.py                # DLP engine (Python)
│   ├── train_spam_classifier.py       # ML training pipeline
│   ├── telegram_bot.py                # Telegram bot
│   ├── msds_evaluator.py              # MSDS metric implementation
│   ├── msds_experiment.py             # MSDS evaluation runner (115 cases)
│   ├── msds_test_dataset.py           # Development test dataset
│   ├── msds_independent_validation.py # Independent validation (54 cases)
│   ├── msds_research_comparison.py    # MSDS vs F1 comparison experiment
│   ├── spam_real_world_test.py        # Real-world SMS validation
│   ├── sri_lankan_sms_dataset.py      # SL dataset generator (915 messages)
│   ├── retrain_with_sl_data.py        # Combined retraining script
│   ├── export_model.py                # Model export for Flutter
│   ├── spam.csv                       # UCI SMS Spam Collection
│   ├── sri_lankan_sms.csv             # Generated SL dataset
│   ├── spam_classifier_pipeline.pkl   # Trained model (scikit-learn)
│   ├── msds_console.html              # MSDS web console
│   ├── requirements.txt               # Python dependencies
│   ├── Procfile                       # Deployment config
│   └── results/                       # JSON evaluation reports
├── flutter_app/
│   ├── pubspec.yaml                   # Flutter dependencies + assets
│   ├── lib/
│   │   ├── main.dart                  # App entry point
│   │   ├── screens/
│   │   │   ├── splash_screen.dart     # Splash + offline mode
│   │   │   ├── dashboard_screen.dart  # Main dashboard
│   │   │   ├── spam_check_screen.dart # Manual spam check
│   │   │   ├── dlp_check_screen.dart  # Outgoing message guard
│   │   │   ├── protection_screen.dart # Real-time SMS + clipboard
│   │   │   ├── logs_screen.dart       # Alert history
│   │   │   ├── settings_screen.dart   # Configuration
│   │   │   ├── handbook_screen.dart   # Security education
│   │   │   └── gmail_connect_screen.dart # Gmail OAuth
│   │   └── services/
│   │       ├── local_spam_classifier.dart   # On-device spam ML
│   │       ├── local_dlp_detector.dart      # On-device DLP
│   │       ├── local_inference_service.dart  # Unified local-first service
│   │       ├── api_service.dart             # Backend API client
│   │       ├── sms_monitor_service.dart     # SMS listener
│   │       ├── clipboard_monitor_service.dart # Clipboard DLP
│   │       ├── notification_service.dart    # Local notifications
│   │       └── gmail_service.dart           # Gmail OAuth service
│   ├── assets/
│   │   └── spam_model.json            # Exported model (472 KB)
│   └── android/
│       └── app/src/main/AndroidManifest.xml # Permissions
└── docs/
    └── FYP_REPORT.md                  # This report
```

### Appendix E: Ethical Approval

> **[PLACEHOLDER: If your university required ethical approval for the project, include the approval form or reference number here. If not required, state:]**
>
> This project did not involve collection of personal data from human subjects. All test data was either publicly available (UCI dataset), synthetically generated, or voluntarily contributed by the researcher. Ethical approval was not required per [IIT/Westminster guidelines].
